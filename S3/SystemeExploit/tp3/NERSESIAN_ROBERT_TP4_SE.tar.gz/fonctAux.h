#ifndef DEF_FONCTAUX
#define DEF_FONCTAUX

//redirige la sortie standard puis écris le résultat d'une commande avant un chevron
char** ecrireFichier(char** entree, char sortie[], int tailleEntree);

#endif
