#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ligne_commande.h"
#include "fonctAux.h"
#include <sys/wait.h>

int main()
{

	char** entree;
	int vide, retourFork;
	int i;
	while (1)
	{

		printf("Shell$"); //Affichage prompt
		fflush(stdout);
		entree = lis_ligne();

			if (entree == NULL)	// SI renvoie NULL on quitte
		{
			exit(0);
		}
			vide = ligne_vide(entree);
			if (vide == 0)
		{
			int i = 0;
			for (i = 0; entree[i]!=NULL; i++)
				{
					//on teste si il y a un chevron dans la commande
					if (strcmp(entree[i], ">") == 0 || strcmp(entree[i], "2>") == 0 || strcmp(entree[i], ">>") == 0 || strcmp(entree[i], "2>>") == 0 )
					{
						ecrireFichier(entree, "sortie", i-1);
						break; // si il y a effectivement un chevron, on force la sortie de boucle
					}
				}

			//si le premier terme vaut export on ajoute une variable d'environnement
			if (strcmp(entree[0],"export") == 0)
				{
					char* var = separe_egal(entree[1]);
					setenv(entree[1],var, 1);
				}
			else
			{
				retourFork = fork();
				if (retourFork == 0)
				{

					execvp(entree[0], entree);
				}
			}

			//le père attends le fils
			if (retourFork>0)
			{
				wait(&i);
			}
				if (retourFork<0)
			{
				printf("error dans le fork");
			}
		}
	}
}
