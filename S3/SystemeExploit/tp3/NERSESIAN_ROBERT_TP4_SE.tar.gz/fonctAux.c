#include "fonctAux.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>



char** ecrireFichier(char** entree, char sortie[], int tailleEntree)
{
	//On cherche quel type de chevron est utilisé
	char* chevron = entree[tailleEntree+1];
	if(strcmp(chevron,">") == 0 || strcmp(chevron,"2>") == 0)
	{
		if (fd = open(sortie, O_WRONLY|O_APPEND|O_CREAT, 0666) < 0)
			{
			perror("ERREUR CREATION FICHIER");
			exit(1);
			}	
	}
	else if (strcmp(chevron,">>") == 0 || strcmp(chevron,"2>>") == 0)
	{
		if (fd = open(sortie, O_WRONLY|O_TRUNC|O_CREAT, 0666) < 0)
		{
			perror("ERREUR CREATION FICHIER");
			exit(1);
		}
	}
	else
	{
		perror("ERREUR CHEVRON");
	}

	dup2(fd, 1);
	entree[tailleEntree+1] == NULL;

}